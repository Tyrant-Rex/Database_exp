create
    definer = root@`%` procedure calculate_Month_salary()
begin
    declare v1 int;
    declare month_count int;
    declare p_id int;
    declare sum int;
    set v1=0;
    set month_count=0;
    set sum=0;
    delete from Employee_month_Salary;
    while v1<(select count(*) from Employee_Basic_Information) do
        set p_id=(select ID
                  from Employee_Basic_Information
                  limit v1,1);
        insert into Employee_month_Salary(ID, Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sept, Oct, Nov, `Dec`)VALUES (p_id,0,0,0,0,0,0,0,0,0,0,0,0);
        set v1=v1+1;
        end while ;

    while month_count<12 do
        set v1=0;
        while v1<(select count(*)
                      from Employee_Basic_Information) do

                    set p_id=(select ID
                              from Employee_Basic_Information
                              limit v1,1);

                    set sum=0;
                    set sum=(select ALLOWANCE from Department where deptID=(select deptID from Employee_Basic_Information where ID=p_id))
                        +(select SALARY from Employee_Type where typeID=(
                                      select typeID
                                      from Employee_Basic_Information
                                      where ID=p_id
                                  ))
                        +ifnull((select ewSALARY
                                         from Extra_work_allowance
                                         where ID=p_id and month(ewdate)=case month_count when 0 then 1 when 1 then 2 when 2 then 3 when 3 then 4 when 4 then 5 when 5 then 6 when 6 then 7 when 7 then 8 when 8 then 9 when 9 then 10 when 10 then 11 when 11 then 12 end),0)
                        -ifnull((select sum(Deduction)
                                 from Employee_Attend
                                 where ID=p_id and month(notAttenddate)=case month_count when 0 then 1 when 1 then 2 when 2 then 3 when 3 then 4 when 4 then 5 when 5 then 6 when 6 then 7 when 7 then 8 when 8 then 9 when 9 then 10 when 10 then 11 when 11 then 12 end),0);
                    case month_count when 0 then update Employee_month_Salary set Jan=sum where ID=p_id;
                    when 1 then update Employee_month_Salary set Feb=sum where ID=p_id;
                    when 2 then update Employee_month_Salary set Mar=sum where ID=p_id;
                    when 3 then update Employee_month_Salary set Apr=sum where ID=p_id;
                    when 4 then update Employee_month_Salary set May=sum where ID=p_id;
                    when 5 then update Employee_month_Salary set Jun=sum where ID=p_id;
                    when 6 then update Employee_month_Salary set Jul=sum where ID=p_id;
                    when 7 then update Employee_month_Salary set Aug=sum where ID=p_id;
                    when 8 then update Employee_month_Salary set Sept=sum where ID=p_id;
                    when 9 then update Employee_month_Salary set Oct=sum where ID=p_id;
                    when 10 then update Employee_month_Salary set Nov=sum where ID=p_id;
                    when 11 then update Employee_month_Salary set `Dec`=sum where ID=p_id;
                    end case;
                    set v1=v1+1;
                end while ;
        set month_count=month_count+1;
        end while ;

end;

