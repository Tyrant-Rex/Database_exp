create
    definer = root@`%` procedure calculate_Year_bonus()
begin
    declare v1 int;
    declare sum float;
    declare yearsalary int;
    declare p_id int;
    declare allowance int;
    delete from Sum_Month_Salary;
    set v1=0;
    while v1<(select count(*) from Employee_Basic_Information) do
        set p_id=(select ID
                  from Employee_Basic_Information
                  limit v1,1);
        set sum=0;
        set yearsalary=0;
        set allowance=0;
        set yearsalary=(select Jan from Employee_month_Salary where ID=p_id)+
                (select Feb from Employee_month_Salary where ID=p_id)+
                (select Mar from Employee_month_Salary where ID=p_id)+
                (select Apr from Employee_month_Salary where ID=p_id)+
                (select May from Employee_month_Salary where ID=p_id)+
                (select Jun from Employee_month_Salary where ID=p_id)+
                (select Jul from Employee_month_Salary where ID=p_id)+
                (select Aug from Employee_month_Salary where ID=p_id)+
                (select Sept from Employee_month_Salary where ID=p_id)+
                (select Oct from Employee_month_Salary where ID=p_id)+
                (select Nov from Employee_month_Salary where ID=p_id)+
                (select `Dec` from Employee_month_Salary where ID=p_id);
        set allowance=ifnull((select sum(ewSALARY) from Extra_work_allowance where id=p_id),0);
        set sum=yearsalary/12;
        insert into Sum_Month_Salary(ID,Bonus,year_salary) values (p_id,sum,yearsalary-allowance);
        set v1=v1+1;
        end while ;
end;

