create definer = root@`%` trigger delete_department
    before delete
    on Department
    for each row
begin
        delete from Employee_Basic_Information where Employee_Basic_Information.deptID=OLD.deptID;
        delete from Employee_Type where Employee_Type.deptID=OLD.deptID;
    end;

