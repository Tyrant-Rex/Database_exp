create
    definer = root@`%` procedure calculate_ewSalary()
begin
    declare v1 int;
    declare p_id int;
    declare ewtype_ID int;
    declare ew_time int;
    declare ew_salary int;
    declare Salary int;
    set v1=0;
    set Salary=0;
    while v1<(select count(*) from Extra_work_allowance) do
        set p_id=(select ID from Extra_work_allowance limit v1,1);
        set ewtype_ID=(select ewtypeID from Extra_work_allowance where ID=p_id);
        set ew_time=(select ewtime from Extra_work_allowance where ID=p_id);
        set ew_salary=(select ewtypeSALARY from Extra_work_type where ewtypeID=ewtype_ID);
        update Extra_work_allowance set ewSALARY=ew_time*ew_salary where ID=p_id;
        set v1=v1+1;
        end while ;
end;

