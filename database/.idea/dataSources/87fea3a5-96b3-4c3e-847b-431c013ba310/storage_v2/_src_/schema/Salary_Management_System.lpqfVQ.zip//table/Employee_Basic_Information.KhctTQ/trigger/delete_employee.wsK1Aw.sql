create definer = root@`%` trigger delete_employee
    before delete
    on Employee_Basic_Information
    for each row
begin
        delete from Employee_Attend where Employee_Attend.ID=OLD.ID;
        delete from Employee_month_Salary where Employee_month_Salary.ID=OLD.ID;
        delete from Extra_work_allowance where Extra_work_allowance.ID=OLD.ID;
        delete from Sum_Month_Salary where Sum_Month_Salary.ID=OLD.ID;
        delete from User_login_info_table where User_login_info_table.p_id=OLD.ID;
    end;

